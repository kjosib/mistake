## Northwind CSV ##

### What it is:

* Just a simple data dump from Microsoft's Northwind database turned into multiple CSV files.

My source: https://github.com/tmcnab/northwind-mongo

### What it is not:

* There aren't any employee/product images
* It's a straight data dump - no relations or special magic

Buyer beware, caveat emptor, carthago delenda est et al.
